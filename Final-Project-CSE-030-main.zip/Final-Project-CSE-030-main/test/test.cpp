#include <igloo/igloo.h>

using namespace igloo;

int main(int argc, const char* argv[]){
    TestRunner::RunAllTests(argc, argv);
}